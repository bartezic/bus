create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
DROP INDEX public.index_rails_admin_histories;
DROP INDEX public.index_admin_users_on_reset_password_token;
DROP INDEX public.index_admin_users_on_email;
DROP INDEX public.index_admin_notes_on_resource_type_and_resource_id;
DROP INDEX public.index_active_admin_comments_on_namespace;
DROP INDEX public.index_active_admin_comments_on_author_type_and_author_id;
ALTER TABLE ONLY public.ways DROP CONSTRAINT ways_pkey;
ALTER TABLE ONLY public.visa_prices DROP CONSTRAINT visas_pkey;
ALTER TABLE ONLY public.two_ways_visa_prices DROP CONSTRAINT two_ways_visa_prices_pkey;
ALTER TABLE ONLY public.two_ways_prices DROP CONSTRAINT two_ways_prices_pkey;
ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_pkey;
ALTER TABLE ONLY public.reservations DROP CONSTRAINT reservations_pkey;
ALTER TABLE ONLY public.requests DROP CONSTRAINT requests_pkey;
ALTER TABLE ONLY public.rails_admin_histories DROP CONSTRAINT rails_admin_histories_pkey;
ALTER TABLE ONLY public.one_way_visa_prices DROP CONSTRAINT one_way_visa_prices_pkey;
ALTER TABLE ONLY public.one_way_prices DROP CONSTRAINT one_way_prices_pkey;
ALTER TABLE ONLY public.health_insurance_prices DROP CONSTRAINT health_insurances_pkey;
ALTER TABLE ONLY public.departures DROP CONSTRAINT departures_pkey;
ALTER TABLE ONLY public.departure_dates DROP CONSTRAINT departure_dates_pkey;
ALTER TABLE ONLY public.countries DROP CONSTRAINT countries_pkey;
ALTER TABLE ONLY public.cities DROP CONSTRAINT cities_pkey;
ALTER TABLE ONLY public.carriers DROP CONSTRAINT carriers_pkey;
ALTER TABLE ONLY public.admin_users DROP CONSTRAINT admin_users_pkey;
ALTER TABLE ONLY public.active_admin_comments DROP CONSTRAINT admin_notes_pkey;
ALTER TABLE public.ways ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.visa_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.two_ways_visa_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.two_ways_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tickets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.reservations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.requests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.rails_admin_histories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.one_way_visa_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.one_way_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.health_insurance_prices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.departures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.departure_dates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.countries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.carriers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.admin_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.active_admin_comments ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.ways_id_seq;
DROP TABLE public.ways;
DROP SEQUENCE public.visas_id_seq;
DROP TABLE public.visa_prices;
DROP SEQUENCE public.two_ways_visa_prices_id_seq;
DROP TABLE public.two_ways_visa_prices;
DROP SEQUENCE public.two_ways_prices_id_seq;
DROP TABLE public.two_ways_prices;
DROP SEQUENCE public.tickets_id_seq;
DROP TABLE public.tickets;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.reservations_id_seq;
DROP TABLE public.reservations;
DROP SEQUENCE public.requests_id_seq;
DROP TABLE public.requests;
DROP SEQUENCE public.rails_admin_histories_id_seq;
DROP TABLE public.rails_admin_histories;
DROP SEQUENCE public.one_way_visa_prices_id_seq;
DROP TABLE public.one_way_visa_prices;
DROP SEQUENCE public.one_way_prices_id_seq;
DROP TABLE public.one_way_prices;
DROP SEQUENCE public.health_insurances_id_seq;
DROP TABLE public.health_insurance_prices;
DROP SEQUENCE public.departures_id_seq;
DROP TABLE public.departures;
DROP SEQUENCE public.departure_dates_id_seq;
DROP TABLE public.departure_dates;
DROP SEQUENCE public.countries_id_seq;
DROP TABLE public.countries;
DROP SEQUENCE public.cities_id_seq;
DROP TABLE public.cities;
DROP SEQUENCE public.carriers_id_seq;
DROP TABLE public.carriers;
DROP SEQUENCE public.admin_users_id_seq;
DROP TABLE public.admin_users;
DROP SEQUENCE public.admin_notes_id_seq;
DROP TABLE public.active_admin_comments;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: active_admin_comments; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE active_admin_comments (
    id integer NOT NULL,
    resource_id character varying(255) NOT NULL,
    resource_type character varying(255) NOT NULL,
    author_id integer,
    author_type character varying(255),
    body text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    namespace character varying(255)
);


ALTER TABLE public.active_admin_comments OWNER TO bus;

--
-- Name: admin_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE admin_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_notes_id_seq OWNER TO bus;

--
-- Name: admin_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE admin_notes_id_seq OWNED BY active_admin_comments.id;


--
-- Name: admin_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('admin_notes_id_seq', 1, false);


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE admin_users (
    id integer NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying(255) DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying(255),
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying(255),
    last_sign_in_ip character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.admin_users OWNER TO bus;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE admin_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_users_id_seq OWNER TO bus;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE admin_users_id_seq OWNED BY admin_users.id;


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('admin_users_id_seq', 2, true);


--
-- Name: carriers; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE carriers (
    id integer NOT NULL,
    name character varying(255),
    city_id integer,
    address character varying(255),
    phone character varying(255),
    telephone character varying(255),
    fax character varying(255),
    email character varying(255),
    web_site character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.carriers OWNER TO bus;

--
-- Name: carriers_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE carriers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carriers_id_seq OWNER TO bus;

--
-- Name: carriers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE carriers_id_seq OWNED BY carriers.id;


--
-- Name: carriers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('carriers_id_seq', 16, true);


--
-- Name: cities; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE cities (
    id integer NOT NULL,
    name character varying(255),
    country_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.cities OWNER TO bus;

--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE cities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cities_id_seq OWNER TO bus;

--
-- Name: cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE cities_id_seq OWNED BY cities.id;


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('cities_id_seq', 34, true);


--
-- Name: countries; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE countries (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.countries OWNER TO bus;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.countries_id_seq OWNER TO bus;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE countries_id_seq OWNED BY countries.id;


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('countries_id_seq', 2, true);


--
-- Name: departure_dates; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE departure_dates (
    id integer NOT NULL,
    day_of_life date,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.departure_dates OWNER TO bus;

--
-- Name: departure_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE departure_dates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departure_dates_id_seq OWNER TO bus;

--
-- Name: departure_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE departure_dates_id_seq OWNED BY departure_dates.id;


--
-- Name: departure_dates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('departure_dates_id_seq', 1232, true);


--
-- Name: departures; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE departures (
    id integer NOT NULL,
    trip_number character varying(255),
    departure_date_id integer,
    ticket_id integer,
    direction boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.departures OWNER TO bus;

--
-- Name: departures_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE departures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departures_id_seq OWNER TO bus;

--
-- Name: departures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE departures_id_seq OWNED BY departures.id;


--
-- Name: departures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('departures_id_seq', 1202, true);


--
-- Name: health_insurance_prices; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE health_insurance_prices (
    id integer NOT NULL,
    ticket_id integer,
    adult integer,
    child integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.health_insurance_prices OWNER TO bus;

--
-- Name: health_insurances_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE health_insurances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.health_insurances_id_seq OWNER TO bus;

--
-- Name: health_insurances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE health_insurances_id_seq OWNED BY health_insurance_prices.id;


--
-- Name: health_insurances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('health_insurances_id_seq', 1, true);


--
-- Name: one_way_prices; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE one_way_prices (
    id integer NOT NULL,
    ticket_id integer,
    adult integer,
    child integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.one_way_prices OWNER TO bus;

--
-- Name: one_way_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE one_way_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.one_way_prices_id_seq OWNER TO bus;

--
-- Name: one_way_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE one_way_prices_id_seq OWNED BY one_way_prices.id;


--
-- Name: one_way_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('one_way_prices_id_seq', 4, true);


--
-- Name: one_way_visa_prices; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE one_way_visa_prices (
    id integer NOT NULL,
    ticket_id integer,
    adult integer,
    child integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.one_way_visa_prices OWNER TO bus;

--
-- Name: one_way_visa_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE one_way_visa_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.one_way_visa_prices_id_seq OWNER TO bus;

--
-- Name: one_way_visa_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE one_way_visa_prices_id_seq OWNED BY one_way_visa_prices.id;


--
-- Name: one_way_visa_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('one_way_visa_prices_id_seq', 1, false);


--
-- Name: rails_admin_histories; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE rails_admin_histories (
    id integer NOT NULL,
    message text,
    username character varying(255),
    item integer,
    "table" character varying(255),
    month smallint,
    year bigint,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.rails_admin_histories OWNER TO bus;

--
-- Name: rails_admin_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE rails_admin_histories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rails_admin_histories_id_seq OWNER TO bus;

--
-- Name: rails_admin_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE rails_admin_histories_id_seq OWNED BY rails_admin_histories.id;


--
-- Name: rails_admin_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('rails_admin_histories_id_seq', 1, false);


--
-- Name: requests; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE requests (
    id integer NOT NULL,
    city_from_id integer,
    city_to_id integer,
    one_way boolean,
    visa boolean,
    adult integer,
    child integer,
    name character varying(255),
    phone character varying(255),
    email character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    date_from date,
    date_to date,
    notice character varying(255)
);


ALTER TABLE public.requests OWNER TO bus;

--
-- Name: requests_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.requests_id_seq OWNER TO bus;

--
-- Name: requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE requests_id_seq OWNED BY requests.id;


--
-- Name: requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('requests_id_seq', 1, false);


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE reservations (
    id integer NOT NULL,
    city_from_id integer,
    city_to_id integer,
    departure_from_id integer,
    departure_to_id integer,
    one_way boolean,
    visa boolean,
    adult integer,
    child integer,
    phone character varying(255),
    email character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    name character varying(255)
);


ALTER TABLE public.reservations OWNER TO bus;

--
-- Name: reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE reservations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reservations_id_seq OWNER TO bus;

--
-- Name: reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE reservations_id_seq OWNED BY reservations.id;


--
-- Name: reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('reservations_id_seq', 4, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO bus;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE tickets (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    carrier_id integer
);


ALTER TABLE public.tickets OWNER TO bus;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tickets_id_seq OWNER TO bus;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE tickets_id_seq OWNED BY tickets.id;


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('tickets_id_seq', 13, true);


--
-- Name: two_ways_prices; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE two_ways_prices (
    id integer NOT NULL,
    ticket_id integer,
    adult integer,
    child integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.two_ways_prices OWNER TO bus;

--
-- Name: two_ways_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE two_ways_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.two_ways_prices_id_seq OWNER TO bus;

--
-- Name: two_ways_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE two_ways_prices_id_seq OWNED BY two_ways_prices.id;


--
-- Name: two_ways_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('two_ways_prices_id_seq', 13, true);


--
-- Name: two_ways_visa_prices; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE two_ways_visa_prices (
    id integer NOT NULL,
    ticket_id integer,
    adult integer,
    child integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.two_ways_visa_prices OWNER TO bus;

--
-- Name: two_ways_visa_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE two_ways_visa_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.two_ways_visa_prices_id_seq OWNER TO bus;

--
-- Name: two_ways_visa_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE two_ways_visa_prices_id_seq OWNED BY two_ways_visa_prices.id;


--
-- Name: two_ways_visa_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('two_ways_visa_prices_id_seq', 6, true);


--
-- Name: visa_prices; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE visa_prices (
    id integer NOT NULL,
    ticket_id integer,
    adult integer,
    child integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.visa_prices OWNER TO bus;

--
-- Name: visas_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE visas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visas_id_seq OWNER TO bus;

--
-- Name: visas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE visas_id_seq OWNED BY visa_prices.id;


--
-- Name: visas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('visas_id_seq', 5, true);


--
-- Name: ways; Type: TABLE; Schema: public; Owner: bus; Tablespace: 
--

CREATE TABLE ways (
    id integer NOT NULL,
    city_id integer,
    ticket_id integer,
    direction boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    place_stop character varying(255),
    time_stop time without time zone
);


ALTER TABLE public.ways OWNER TO bus;

--
-- Name: ways_id_seq; Type: SEQUENCE; Schema: public; Owner: bus
--

CREATE SEQUENCE ways_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ways_id_seq OWNER TO bus;

--
-- Name: ways_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bus
--

ALTER SEQUENCE ways_id_seq OWNED BY ways.id;


--
-- Name: ways_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bus
--

SELECT pg_catalog.setval('ways_id_seq', 484, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY active_admin_comments ALTER COLUMN id SET DEFAULT nextval('admin_notes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY admin_users ALTER COLUMN id SET DEFAULT nextval('admin_users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY carriers ALTER COLUMN id SET DEFAULT nextval('carriers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY cities ALTER COLUMN id SET DEFAULT nextval('cities_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY countries ALTER COLUMN id SET DEFAULT nextval('countries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY departure_dates ALTER COLUMN id SET DEFAULT nextval('departure_dates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY departures ALTER COLUMN id SET DEFAULT nextval('departures_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY health_insurance_prices ALTER COLUMN id SET DEFAULT nextval('health_insurances_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY one_way_prices ALTER COLUMN id SET DEFAULT nextval('one_way_prices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY one_way_visa_prices ALTER COLUMN id SET DEFAULT nextval('one_way_visa_prices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY rails_admin_histories ALTER COLUMN id SET DEFAULT nextval('rails_admin_histories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY requests ALTER COLUMN id SET DEFAULT nextval('requests_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY reservations ALTER COLUMN id SET DEFAULT nextval('reservations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY tickets ALTER COLUMN id SET DEFAULT nextval('tickets_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY two_ways_prices ALTER COLUMN id SET DEFAULT nextval('two_ways_prices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY two_ways_visa_prices ALTER COLUMN id SET DEFAULT nextval('two_ways_visa_prices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY visa_prices ALTER COLUMN id SET DEFAULT nextval('visas_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bus
--

ALTER TABLE ONLY ways ALTER COLUMN id SET DEFAULT nextval('ways_id_seq'::regclass);


--
-- Data for Name: active_admin_comments; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY active_admin_comments (id, resource_id, resource_type, author_id, author_type, body, created_at, updated_at, namespace) FROM stdin;
\.
copy active_admin_comments (id, resource_id, resource_type, author_id, author_type, body, created_at, updated_at, namespace)  from '$$PATH$$/2031.dat' ;
--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY admin_users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at) FROM stdin;
\.
copy admin_users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at)  from '$$PATH$$/2030.dat' ;
--
-- Data for Name: carriers; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY carriers (id, name, city_id, address, phone, telephone, fax, email, web_site, created_at, updated_at) FROM stdin;
\.
copy carriers (id, name, city_id, address, phone, telephone, fax, email, web_site, created_at, updated_at)  from '$$PATH$$/2035.dat' ;
--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY cities (id, name, country_id, created_at, updated_at) FROM stdin;
\.
copy cities (id, name, country_id, created_at, updated_at)  from '$$PATH$$/2029.dat' ;
--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY countries (id, name, created_at, updated_at) FROM stdin;
\.
copy countries (id, name, created_at, updated_at)  from '$$PATH$$/2028.dat' ;
--
-- Data for Name: departure_dates; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY departure_dates (id, day_of_life, created_at, updated_at) FROM stdin;
\.
copy departure_dates (id, day_of_life, created_at, updated_at)  from '$$PATH$$/2036.dat' ;
--
-- Data for Name: departures; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY departures (id, trip_number, departure_date_id, ticket_id, direction, created_at, updated_at) FROM stdin;
\.
copy departures (id, trip_number, departure_date_id, ticket_id, direction, created_at, updated_at)  from '$$PATH$$/2037.dat' ;
--
-- Data for Name: health_insurance_prices; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY health_insurance_prices (id, ticket_id, adult, child, created_at, updated_at) FROM stdin;
\.
copy health_insurance_prices (id, ticket_id, adult, child, created_at, updated_at)  from '$$PATH$$/2043.dat' ;
--
-- Data for Name: one_way_prices; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY one_way_prices (id, ticket_id, adult, child, created_at, updated_at) FROM stdin;
\.
copy one_way_prices (id, ticket_id, adult, child, created_at, updated_at)  from '$$PATH$$/2038.dat' ;
--
-- Data for Name: one_way_visa_prices; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY one_way_visa_prices (id, ticket_id, adult, child, created_at, updated_at) FROM stdin;
\.
copy one_way_visa_prices (id, ticket_id, adult, child, created_at, updated_at)  from '$$PATH$$/2040.dat' ;
--
-- Data for Name: rails_admin_histories; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY rails_admin_histories (id, message, username, item, "table", month, year, created_at, updated_at) FROM stdin;
\.
copy rails_admin_histories (id, message, username, item, "table", month, year, created_at, updated_at)  from '$$PATH$$/2034.dat' ;
--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY requests (id, city_from_id, city_to_id, one_way, visa, adult, child, name, phone, email, created_at, updated_at, date_from, date_to, notice) FROM stdin;
\.
copy requests (id, city_from_id, city_to_id, one_way, visa, adult, child, name, phone, email, created_at, updated_at, date_from, date_to, notice)  from '$$PATH$$/2045.dat' ;
--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY reservations (id, city_from_id, city_to_id, departure_from_id, departure_to_id, one_way, visa, adult, child, phone, email, created_at, updated_at, name) FROM stdin;
\.
copy reservations (id, city_from_id, city_to_id, departure_from_id, departure_to_id, one_way, visa, adult, child, phone, email, created_at, updated_at, name)  from '$$PATH$$/2044.dat' ;
--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY schema_migrations (version) FROM stdin;
\.
copy schema_migrations (version)  from '$$PATH$$/2027.dat' ;
--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY tickets (id, created_at, updated_at, carrier_id) FROM stdin;
\.
copy tickets (id, created_at, updated_at, carrier_id)  from '$$PATH$$/2032.dat' ;
--
-- Data for Name: two_ways_prices; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY two_ways_prices (id, ticket_id, adult, child, created_at, updated_at) FROM stdin;
\.
copy two_ways_prices (id, ticket_id, adult, child, created_at, updated_at)  from '$$PATH$$/2039.dat' ;
--
-- Data for Name: two_ways_visa_prices; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY two_ways_visa_prices (id, ticket_id, adult, child, created_at, updated_at) FROM stdin;
\.
copy two_ways_visa_prices (id, ticket_id, adult, child, created_at, updated_at)  from '$$PATH$$/2041.dat' ;
--
-- Data for Name: visa_prices; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY visa_prices (id, ticket_id, adult, child, created_at, updated_at) FROM stdin;
\.
copy visa_prices (id, ticket_id, adult, child, created_at, updated_at)  from '$$PATH$$/2042.dat' ;
--
-- Data for Name: ways; Type: TABLE DATA; Schema: public; Owner: bus
--

COPY ways (id, city_id, ticket_id, direction, created_at, updated_at, place_stop, time_stop) FROM stdin;
\.
copy ways (id, city_id, ticket_id, direction, created_at, updated_at, place_stop, time_stop)  from '$$PATH$$/2033.dat' ;
--
-- Name: admin_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY active_admin_comments
    ADD CONSTRAINT admin_notes_pkey PRIMARY KEY (id);


--
-- Name: admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: carriers_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY carriers
    ADD CONSTRAINT carriers_pkey PRIMARY KEY (id);


--
-- Name: cities_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: countries_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: departure_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY departure_dates
    ADD CONSTRAINT departure_dates_pkey PRIMARY KEY (id);


--
-- Name: departures_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY departures
    ADD CONSTRAINT departures_pkey PRIMARY KEY (id);


--
-- Name: health_insurances_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY health_insurance_prices
    ADD CONSTRAINT health_insurances_pkey PRIMARY KEY (id);


--
-- Name: one_way_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY one_way_prices
    ADD CONSTRAINT one_way_prices_pkey PRIMARY KEY (id);


--
-- Name: one_way_visa_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY one_way_visa_prices
    ADD CONSTRAINT one_way_visa_prices_pkey PRIMARY KEY (id);


--
-- Name: rails_admin_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY rails_admin_histories
    ADD CONSTRAINT rails_admin_histories_pkey PRIMARY KEY (id);


--
-- Name: requests_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: two_ways_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY two_ways_prices
    ADD CONSTRAINT two_ways_prices_pkey PRIMARY KEY (id);


--
-- Name: two_ways_visa_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY two_ways_visa_prices
    ADD CONSTRAINT two_ways_visa_prices_pkey PRIMARY KEY (id);


--
-- Name: visas_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY visa_prices
    ADD CONSTRAINT visas_pkey PRIMARY KEY (id);


--
-- Name: ways_pkey; Type: CONSTRAINT; Schema: public; Owner: bus; Tablespace: 
--

ALTER TABLE ONLY ways
    ADD CONSTRAINT ways_pkey PRIMARY KEY (id);


--
-- Name: index_active_admin_comments_on_author_type_and_author_id; Type: INDEX; Schema: public; Owner: bus; Tablespace: 
--

CREATE INDEX index_active_admin_comments_on_author_type_and_author_id ON active_admin_comments USING btree (author_type, author_id);


--
-- Name: index_active_admin_comments_on_namespace; Type: INDEX; Schema: public; Owner: bus; Tablespace: 
--

CREATE INDEX index_active_admin_comments_on_namespace ON active_admin_comments USING btree (namespace);


--
-- Name: index_admin_notes_on_resource_type_and_resource_id; Type: INDEX; Schema: public; Owner: bus; Tablespace: 
--

CREATE INDEX index_admin_notes_on_resource_type_and_resource_id ON active_admin_comments USING btree (resource_type, resource_id);


--
-- Name: index_admin_users_on_email; Type: INDEX; Schema: public; Owner: bus; Tablespace: 
--

CREATE UNIQUE INDEX index_admin_users_on_email ON admin_users USING btree (email);


--
-- Name: index_admin_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: bus; Tablespace: 
--

CREATE UNIQUE INDEX index_admin_users_on_reset_password_token ON admin_users USING btree (reset_password_token);


--
-- Name: index_rails_admin_histories; Type: INDEX; Schema: public; Owner: bus; Tablespace: 
--

CREATE INDEX index_rails_admin_histories ON rails_admin_histories USING btree (item, "table", month, year);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: bus; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

